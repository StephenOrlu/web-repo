﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment2.Models
{
    public class ViewBadWordsViewModel
    {
        public List<BadWord> BadWords
        {
            get;
            set;
        }
    }
}
